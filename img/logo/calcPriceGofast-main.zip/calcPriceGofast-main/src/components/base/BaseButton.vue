<template>
    <button class="btn btn-secondary btn-md mx-2">
        <slot></slot>
    </button>
</template>