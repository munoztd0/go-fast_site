<template>
    <div class="card">
        <slot></slot>
    </div>
</template>

<script>
export default {
    props : ['title']
}
</script>