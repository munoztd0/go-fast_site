# calcPriceGofast
Created with CodeSandbox
